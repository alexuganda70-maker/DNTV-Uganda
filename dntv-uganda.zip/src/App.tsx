import { useState, useEffect } from 'react';
import { 
  Phone, 
  Mail, 
  Clock, 
  Facebook, 
  Twitter, 
  Youtube, 
  Search, 
  Moon, 
  Sun, 
  Menu, 
  Bolt, 
  PlayCircle, 
  Newspaper, 
  ChevronLeft, 
  ChevronRight, 
  User, 
  Calendar,
  Globe,
  Tv,
  Podcast,
  MapPin
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';

// --- Data ---
const TOP_HEADLINES = [
  { id: 1, title: "President to Address Nation on Economic Recovery Plan", time: "15 minutes ago" },
  { id: 2, title: "Supreme Court Hears Landmark Constitutional Petition", time: "42 minutes ago" },
  { id: 3, title: "Agricultural Exports Rise by 23% in Q1 2024", time: "1 hour ago" },
  { id: 4, title: "New COVID Variant Detected, Health Ministry Issues Alert", time: "2 hours ago" },
  { id: 5, title: "Kampala City Council Approves New Transport Master Plan", time: "3 hours ago" },
];

const NEWS_CARDS = [
  {
    id: 1,
    category: "Politics",
    categoryClass: "bg-dark-blue text-white",
    title: "New Cabinet Ministers Sworn In After Major Government Reshuffle",
    excerpt: "President appoints 15 new cabinet ministers in a major government reshuffle aimed at improving service delivery and economic recovery.",
    author: "John Musoke",
    date: "April 15, 2024",
    image: "https://images.unsplash.com/photo-1588681664899-f142ff2dc9b1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 2,
    category: "Business",
    categoryClass: "bg-emerald-600 text-white",
    title: "Bank of Uganda Maintains Key Interest Rate Amid Inflation Concerns",
    excerpt: "Central bank holds rate steady at 9.5% as inflation shows signs of easing, economic growth projections revised upwards to 6.2%.",
    author: "Sarah Nalwoga",
    date: "April 14, 2024",
    image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 3,
    category: "Sports",
    categoryClass: "bg-blue-500 text-white",
    title: "Uganda Cranes Qualify for AFCON 2025 After Dramatic Win",
    excerpt: "National football team secures spot in African Cup of Nations with dramatic 2-1 win over neighboring rivals in final qualifier match.",
    author: "David Ssemwogerere",
    date: "April 13, 2024",
    image: "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  }
];

const PRIME_MINISTERS = [
  { name: "Joash Mayanja Nkangi", clan: "Mutima (Heart) clan", desc: "Served as Prime Minister during a transformative period in Buganda's history." },
  { name: "Joseph Mulwanyamuli Ssemwogerere", clan: "Lugave (Pangolin) clan", desc: "Distinguished leader who contributed significantly to the kingdom's development." },
  { name: "Daniel Muliika", clan: "Nyonyi Namunyoona (Pied Crow) clan", desc: "Noted for his dedication to preserving Buganda's cultural heritage." },
  { name: "Eng. J.B. Walusimbi", clan: "Ffumbe (Civet Cat) clan", desc: "Engineer and leader who championed infrastructure development." },
  { name: "Charles Peter Mayiga (current)", clan: "Mutima (Heart) clan", desc: "Current Prime Minister leading Buganda with vision and innovation." },
];

const MASAZA_GROUPS = [
  {
    name: "Group A - Bulange",
    teams: [
      { name: "Buluuli", gp: 10, w: 5, d: 4, l: 1, f: 10, a: 3, gd: "+7", p: 19 },
      { name: "Busujju", gp: 10, w: 5, d: 3, l: 2, f: 11, a: 8, gd: "+3", p: 18 },
      { name: "Ssese", gp: 10, w: 6, d: 0, l: 4, f: 10, a: 8, gd: "+2", p: 18 },
      { name: "Gomba", gp: 10, w: 2, d: 3, l: 5, f: 7, a: 9, gd: "-2", p: 9 },
      { name: "Buddu", gp: 10, w: 2, d: 3, l: 5, f: 6, a: 11, gd: "-5", p: 9 },
      { name: "Busiro", gp: 10, w: 2, d: 3, l: 5, f: 5, a: 10, gd: "-5", p: 9 },
    ]
  },
  {
    name: "Group B - Masengere",
    teams: [
      { name: "Buweekula", gp: 10, w: 7, d: 1, l: 2, f: 16, a: 6, gd: "+10", p: 22 },
      { name: "Mawokota", gp: 10, w: 5, d: 3, l: 2, f: 11, a: 4, gd: "+7", p: 18 },
      { name: "Bugerere", gp: 10, w: 4, d: 5, l: 1, f: 10, a: 9, gd: "+1", p: 17 },
      { name: "Kyaddondo", gp: 10, w: 3, d: 3, l: 4, f: 12, a: 10, gd: "+2", p: 12 },
      { name: "Bulemeezi", gp: 10, w: 2, d: 2, l: 6, f: 3, a: 9, gd: "-6", p: 8 },
      { name: "Buvuma", gp: 10, w: 1, d: 2, l: 7, f: 5, a: 19, gd: "-14", p: 5 },
    ]
  }
];

const DISTRICT_TEAMS = [
  { team: "Buddu", district: "Masaka" },
  { team: "Bugerere", district: "Kayunga" },
  { team: "Bulemeezi", district: "Luweero" },
  { team: "Buluuli", district: "Nakasongola" },
  { team: "Busiro", district: "Wakiso" },
  { team: "Busujju", district: "Mityana" },
  { team: "Butambala", district: "Butambala" },
  { team: "Buvuma", district: "Buvuma" },
  { team: "Buweekula", district: "Mubende" },
  { team: "Gomba", district: "Gomba" },
  { team: "Kabula", district: "Rakai" },
  { team: "Kkooki", district: "Rakai" },
  { team: "Kyaddondo", district: "Wakiso" },
  { team: "Kyaggwe", district: "Mukono" },
  { team: "Mawogola", district: "Sembabule" },
  { team: "Mawokota", district: "Mpigi" },
  { team: "Ssese", district: "Kalangala" },
  { team: "Ssingo", district: "Mityana" },
];

export default function App() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  return (
    <div className={cn("min-h-screen transition-colors duration-300", isDarkMode ? "bg-slate-900 text-white" : "bg-white text-dark-gray")}>
      {/* --- Header --- */}
      <header className="sticky top-0 z-50 shadow-md">
        {/* Top bar */}
        <div className="bg-dark-blue text-white py-2 text-xs md:text-sm border-b border-white/10">
          <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-2">
            <div className="flex gap-4 md:gap-6 items-center">
              <span className="flex items-center gap-1.5"><Phone size={14} /> +256 200 999 594</span>
              <span className="flex items-center gap-1.5"><Mail size={14} /> info@dntvuganda.com</span>
              <span className="hidden sm:flex items-center gap-1.5"><Clock size={14} /> 24/7 News Coverage</span>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex gap-2">
                {[Facebook, Twitter, Youtube].map((Icon, i) => (
                  <a key={i} href="#" className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center hover:bg-primary-red transition-all">
                    <Icon size={14} />
                  </a>
                ))}
              </div>
              <button 
                onClick={() => setIsDarkMode(!isDarkMode)}
                className="flex items-center gap-1.5 bg-white/10 px-3 py-1 rounded-md cursor-pointer hover:bg-white/20 transition-all font-medium"
              >
                {isDarkMode ? <Sun size={14} /> : <Moon size={14} />}
                <span>{isDarkMode ? "Light Mode" : "Dark Mode"}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Main Header */}
        <div className="bg-white dark:bg-slate-900 py-4 border-b dark:border-slate-800">
          <div className="container mx-auto px-4 flex justify-between items-center">
            <div className="flex items-center gap-4">
              <div className="flex flex-col">
                <img 
                  src="https://drive.google.com/thumbnail?id=1lC_4xPQEEoEpTJfeONZaDSVA-kjOB1n6" 
                  alt="DNTV Uganda Logo" 
                  className="h-12 md:h-16 w-auto object-contain dark:invert"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="hidden md:flex items-center h-8 pl-4 border-l-2 border-primary-red italic text-sm text-dark-gray dark:text-slate-400">
                We are Your Word Reliable
              </div>
            </div>

            <nav className="hidden lg:flex gap-6">
              {["Home", "News", "Politics", "Business", "Sports", "Entertainment", "Lifestyle", "Tournament"].map((item) => (
                <a key={item} href="#" className="font-semibold text-dark-blue dark:text-slate-200 hover:text-primary-red relative group py-1">
                  {item}
                  <span className={cn("absolute bottom-0 left-0 w-0 h-0.5 bg-primary-red transition-all group-hover:w-full", item === "Home" && "w-full")} />
                </a>
              ))}
            </nav>

            <div className="flex items-center gap-4">
              <div className="relative hidden sm:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-dark-gray dark:text-slate-400" size={16} />
                <input 
                  type="text" 
                  placeholder="Search news..." 
                  className="pl-10 pr-4 py-2 border dark:border-slate-700 rounded-md bg-light-gray dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-primary-red w-48 xl:w-64"
                />
              </div>
              <button className="bg-primary-red text-white px-6 py-2 rounded-md font-semibold hover:bg-secondary-red transition-all text-sm hidden sm:block">
                Subscribe
              </button>
              <button 
                className="lg:hidden text-dark-blue dark:text-white"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                <Menu size={28} />
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="lg:hidden bg-white dark:bg-slate-900 border-b dark:border-slate-800 overflow-hidden"
            >
              <div className="container mx-auto px-4 py-6 flex flex-col gap-4">
                {["Home", "News", "Politics", "Business", "Sports", "Entertainment", "Lifestyle", "Tournament"].map((item) => (
                  <a key={item} href="#" className="font-semibold text-dark-blue dark:text-slate-200 py-2 border-b dark:border-slate-800 last:border-0">
                    {item}
                  </a>
                ))}
                <div className="pt-4 flex flex-col gap-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-dark-gray dark:text-slate-400" size={16} />
                    <input 
                      type="text" 
                      placeholder="Search news..." 
                      className="w-full pl-10 pr-4 py-3 border dark:border-slate-700 rounded-md bg-light-gray dark:bg-slate-800"
                    />
                  </div>
                  <button className="bg-primary-red text-white py-3 rounded-md font-semibold">
                    Subscribe
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Breaking News Ticker */}
        <div className="bg-primary-red text-white py-2.5 overflow-hidden relative">
          <div className="container mx-auto px-4 flex items-center">
            <div className="bg-black/20 px-4 py-1 font-bold whitespace-nowrap flex items-center gap-2 z-10 rounded-sm">
              <Bolt size={16} /> BREAKING
            </div>
            <div className="flex-1 pl-6 overflow-hidden">
              <div className="animate-ticker whitespace-nowrap font-semibold">
                Parliament passes controversial education bill after marathon session • Uganda shilling strengthens against dollar amid Central Bank interventions • National team coach announces squad for upcoming AFCON qualifiers • New infrastructure projects launched in Northern Uganda
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* --- Hero Section --- */}
      <section className="py-8 md:py-12 bg-gradient-to-r from-light-gray/50 to-white dark:from-slate-950 dark:to-slate-900">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Live Player */}
            <div className="lg:col-span-2 bg-dark-blue rounded-xl overflow-hidden shadow-2xl">
              <div className="bg-primary-red text-white px-6 py-4 flex justify-between items-center">
                <div className="flex items-center gap-3 font-bold">
                  <div className="w-2.5 h-2.5 rounded-full bg-white animate-pulse" />
                  <span>LIVE NOW</span>
                </div>
                <div className="text-sm font-medium opacity-90">DNTV Uganda - 24/7 News Channel</div>
              </div>
              <div className="aspect-video relative flex items-center justify-center bg-black group cursor-pointer">
                <img 
                  src="https://images.unsplash.com/photo-1574267432553-4b4628081c31?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80" 
                  alt="Live Stream" 
                  className="absolute inset-0 w-full h-full object-cover opacity-40"
                  referrerPolicy="no-referrer"
                />
                <div className="relative z-10 text-center p-6 text-white">
                  <PlayCircle size={80} className="mx-auto mb-6 opacity-90 group-hover:scale-110 transition-transform" />
                  <h3 className="text-2xl md:text-3xl font-bold mb-2">DNTV Uganda Live Broadcast</h3>
                  <p className="text-white/70 max-w-md mx-auto">Watch our 24/7 news coverage and updates from across Uganda</p>
                  <button className="mt-8 bg-primary-red hover:bg-secondary-red text-white px-8 py-3 rounded-full font-bold transition-all shadow-lg">
                    Watch Live Stream
                  </button>
                </div>
              </div>
            </div>

            {/* Top Headlines */}
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg overflow-hidden flex flex-col">
              <div className="bg-dark-blue text-white px-6 py-4 font-bold text-lg flex justify-between items-center">
                <span>TOP HEADLINES</span>
                <Newspaper size={20} />
              </div>
              <div className="flex-1 p-4 overflow-y-auto">
                {TOP_HEADLINES.map((headline) => (
                  <div key={headline.id} className="py-4 border-b dark:border-slate-700 last:border-0 hover:bg-light-gray dark:hover:bg-slate-700/50 px-4 -mx-4 transition-all cursor-pointer rounded-md">
                    <h4 className="font-bold text-dark-blue dark:text-slate-100 leading-tight mb-2">{headline.title}</h4>
                    <div className="flex items-center gap-2 text-xs text-dark-gray dark:text-slate-400">
                      <Clock size={12} /> {headline.time}
                    </div>
                  </div>
                ))}
              </div>
              <button className="w-full py-4 text-primary-red font-bold text-sm hover:bg-light-gray dark:hover:bg-slate-700 transition-all border-t dark:border-slate-700">
                VIEW ALL HEADLINES
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* --- Prime Ministers Section --- */}
      <section className="py-16 bg-white dark:bg-slate-900">
        <div className="container mx-auto px-4">
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-dark-blue dark:text-white relative pb-4 inline-block">
              Prime Ministers During His Reign
              <span className="absolute bottom-0 left-0 w-16 h-1 bg-primary-red" />
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {PRIME_MINISTERS.map((pm, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -5 }}
                className="bg-light-gray dark:bg-slate-800 p-8 rounded-2xl border-l-4 border-primary-red shadow-sm hover:shadow-md transition-all"
              >
                <h3 className="text-xl font-bold text-dark-blue dark:text-slate-100 mb-2">{pm.name}</h3>
                <span className="inline-block px-4 py-1 bg-primary-red text-white text-xs font-bold rounded-full mb-4">{pm.clan}</span>
                <p className="text-dark-gray dark:text-slate-400 text-sm leading-relaxed">{pm.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* --- Royal Family Section --- */}
      <section className="py-20 bg-dark-blue text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/20 via-transparent to-transparent" />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-bold mb-4">Royal Family</h2>
            <h3 className="text-2xl text-primary-red font-bold mb-8">His Majesty & Her Royal Highness</h3>
            <p className="text-xl leading-relaxed text-white/80 mb-12">
              His Majesty is married to Her Royal Highness Nnaabagereka Sylvia Nagginda, of the Musu (Edible-Rat) clan. 
              The royal couple has a daughter, Princess Ssangalyambogo Sarah Katrina.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
              <div className="group overflow-hidden rounded-2xl border-4 border-primary-red shadow-2xl">
                <img 
                  src="https://buganda.or.ug/wp-content/uploads/2025/02/kabakaaa.jpg" 
                  alt="Kabaka" 
                  className="w-full h-[350px] object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="group overflow-hidden rounded-2xl border-4 border-primary-red shadow-2xl">
                <img 
                  src="https://buganda.or.ug/wp-content/uploads/2025/03/kabakaaa-1536x1036.jpg" 
                  alt="Kabaka with Royal Family" 
                  className="w-full h-[350px] object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* --- Education & Early Life --- */}
      <section className="py-20 bg-white dark:bg-slate-950">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-bold text-dark-blue dark:text-white mb-8 relative pb-4">
                Education and Early Life
                <span className="absolute bottom-0 left-0 w-16 h-1 bg-primary-red" />
              </h2>
              <div className="space-y-6 text-lg text-dark-gray dark:text-slate-400 leading-relaxed">
                <p>
                  During his formative years, the Kabaka attended Buddo Junior School, one of the leading institutions in the Kingdom. 
                  As a young prince, he was immersed in the rich culture and traditions of the Baganda by staying with respected clan leaders and chiefs, 
                  an experience designed to prepare him for future leadership.
                </p>
                <p>
                  He also received private tuition at his father's palace before proceeding to the United Kingdom for further studies. 
                  Upon completing his education, he worked as a journalist and served as an Associate Editor at the African Concord Magazine, 
                  gaining exposure to international affairs and the media industry.
                </p>
              </div>
            </div>
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-full h-full border-4 border-primary-red rounded-2xl -z-10" />
              <img 
                src="https://www.gbnews.com/media-library/donald-trump.webp?id=65161273&width=700&quality=85" 
                alt="Education Context" 
                className="w-full rounded-2xl shadow-2xl"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>

      {/* --- Masaza Cup News --- */}
      <section className="py-20 bg-light-gray dark:bg-slate-900">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-dark-blue dark:text-white mb-12 relative pb-4">
            Masaza Cup 2025 Updates
            <span className="absolute bottom-0 left-0 w-16 h-1 bg-primary-red" />
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2">
              <img 
                src="https://i0.wp.com/kawowo.com/wp-content/uploads/2025/06/Buganda-Masaza-Cup-fans.jpg?resize=780%2C520&ssl=1" 
                alt="Masaza Cup Fans" 
                className="w-full h-[450px] object-cover rounded-2xl shadow-xl mb-8"
                referrerPolicy="no-referrer"
              />
              <h3 className="text-2xl font-bold text-dark-blue dark:text-slate-100 mb-4">Buddu Edges Gomba 1-0 in Thrilling Masaza Cup Opener</h3>
              <div className="space-y-4 text-dark-gray dark:text-slate-400">
                <p>Buganda Masaza Cup defending champions Buddu edged record-holders Gomba 1-0 in a fiercely contested opening fixture at the Sports Arena in Kitovu, Masaka city.</p>
                <p>The lone goal of the match came in the 77th minute courtesy of a stunning long-range strike from midfielder Crispus Sseruwuge.</p>
                <p>Sseruwuge's goal sent the home crowd into a frenzy and sealing Buddu's place in history as the first team in five years to win the tournament's opening match.</p>
              </div>
            </div>
            <div className="space-y-8">
              <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-md border-t-4 border-primary-red">
                <img 
                  src="https://i0.wp.com/kawowo.com/wp-content/uploads/2025/06/Buddu-against-Gomba-in-2025-Masaza-Cup-opener-at-Sports-Arena-Kitovu.jpg?resize=780%2C612&ssl=1" 
                  alt="Match Action" 
                  className="w-full rounded-xl mb-6"
                  referrerPolicy="no-referrer"
                />
                <p className="italic text-dark-gray dark:text-slate-300">
                  Beyond creating pathways for young players, many of whom have graduated to the Uganda Premier League and even the national team — the tournament has become an economic and cultural force.
                </p>
              </div>
              <img 
                src="https://i0.wp.com/kawowo.com/wp-content/uploads/2025/06/Buddu-blue-against-Gomba-in-2025-Masaza-Cup-opener.jpg?resize=780%2C578&ssl=1" 
                alt="Buddu in Action" 
                className="w-full rounded-2xl shadow-md"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>

      {/* --- Political News --- */}
      <section className="py-20 bg-white dark:bg-slate-950">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-dark-blue dark:text-white mb-12 relative pb-4">
            Political News
            <span className="absolute bottom-0 left-0 w-16 h-1 bg-primary-red" />
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="bg-light-gray dark:bg-slate-800 p-8 rounded-3xl shadow-sm hover:shadow-xl transition-all group">
              <h3 className="text-2xl font-bold mb-6 text-dark-blue dark:text-slate-100 group-hover:text-primary-red transition-colors">Bobi Wine Campaigns in Karamoja</h3>
              <img 
                src="https://static.africa-press.net/uganda/sites/34/2026/01/sm_1767800307.36886.jpg" 
                alt="Bobi Wine" 
                className="w-full h-64 object-cover rounded-2xl mb-6 shadow-md"
                referrerPolicy="no-referrer"
              />
              <p className="text-dark-gray dark:text-slate-400 leading-relaxed">
                Uganda. National Unity Platform (NUP) presidential candidate Robert Kyagulanyi, popularly known as Bobi Wine, is expected to campaign today in the Karamoja sub-region, with scheduled rallies in the districts of Amudat, Moroto and Napak.
              </p>
            </div>
            <div className="bg-light-gray dark:bg-slate-800 p-8 rounded-3xl shadow-sm hover:shadow-xl transition-all group">
              <h3 className="text-2xl font-bold mb-6 text-dark-blue dark:text-slate-100 group-hover:text-primary-red transition-colors">President Museveni Secures Seventh Term</h3>
              <img 
                src="https://nexusmedia.ug/wp-content/uploads/2026/01/YOWERI.jpg" 
                alt="President Museveni" 
                className="w-full h-64 object-cover rounded-2xl mb-6 shadow-md"
                referrerPolicy="no-referrer"
              />
              <p className="text-dark-gray dark:text-slate-400 leading-relaxed">
                President Yoweri Museveni secured a seventh term in office, extending his 40-year rule with a commanding 71.65% of the vote, according to official results from the Electoral Commission.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* --- News Grid --- */}
      <section className="py-20 bg-light-gray dark:bg-slate-900">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-end mb-12">
            <h2 className="text-3xl font-bold text-dark-blue dark:text-white relative pb-4">
              Catch Up With The News
              <span className="absolute bottom-0 left-0 w-16 h-1 bg-primary-red" />
            </h2>
            <div className="flex gap-4 mb-4">
              <button className="w-10 h-10 rounded-full bg-white dark:bg-slate-800 flex items-center justify-center shadow-md hover:bg-primary-red hover:text-white transition-all">
                <ChevronLeft size={20} />
              </button>
              <button className="w-10 h-10 rounded-full bg-white dark:bg-slate-800 flex items-center justify-center shadow-md hover:bg-primary-red hover:text-white transition-all">
                <ChevronRight size={20} />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {NEWS_CARDS.map((card) => (
              <motion.div 
                key={card.id}
                whileHover={{ y: -10 }}
                className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-lg group"
              >
                <div className="h-56 overflow-hidden">
                  <img 
                    src={card.image} 
                    alt={card.title} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-6">
                  <span className={cn("inline-block px-4 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider mb-4", card.categoryClass)}>
                    {card.category}
                  </span>
                  <h3 className="text-xl font-bold mb-3 text-dark-blue dark:text-slate-100 leading-tight group-hover:text-primary-red transition-colors">
                    {card.title}
                  </h3>
                  <p className="text-dark-gray dark:text-slate-400 text-sm mb-6 line-clamp-3">
                    {card.excerpt}
                  </p>
                  <div className="flex justify-between items-center text-xs text-dark-gray dark:text-slate-500 pt-4 border-t dark:border-slate-700">
                    <span className="flex items-center gap-1.5"><User size={14} /> {card.author}</span>
                    <span className="flex items-center gap-1.5"><Calendar size={14} /> {card.date}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* --- Tournament Navigation --- */}
      <section className="py-12 bg-white dark:bg-slate-950">
        <div className="container mx-auto px-4">
          <div className="border-4 border-primary-blue rounded-3xl p-8 dark:bg-slate-900 shadow-xl">
            <h2 className="text-2xl font-bold text-dark-blue dark:text-white mb-8 inline-block border-b-2 border-primary-blue pb-2">
              Tournament Navigation 2026
            </h2>
            <div className="flex flex-wrap gap-4 justify-center">
              {["Teams", "Groups", "Fixtures", "Results", "Players", "Top Scorers", "Statistics", "Standings", "2026"].map((item, i) => (
                <a 
                  key={i} 
                  href="#" 
                  className="px-6 py-2.5 border-2 border-primary-blue rounded-xl text-dark-blue dark:text-slate-200 font-bold hover:bg-primary-blue hover:text-white transition-all bg-primary-blue/5"
                >
                  {item}
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* --- Masaza Cup Tables --- */}
      <section className="py-20 bg-dark-blue text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Buganda Kingdom Masaza Cup 2026</h2>
            <p className="text-white/70 text-lg">Uganda's Premier Regional Football Tournament • 18 Teams • 4 Groups • 5 Stadiums</p>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-12">
            {MASAZA_GROUPS.map((group, i) => (
              <div key={i} className="bg-white/5 p-8 rounded-3xl border border-white/10 shadow-2xl backdrop-blur-sm">
                <h3 className="text-2xl font-bold text-primary-red mb-8 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-primary-red flex items-center justify-center text-white text-sm">G</div>
                  {group.name}
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-white/10 text-left">
                        <th className="p-4 rounded-l-lg">Team</th>
                        <th className="p-4 text-center">GP</th>
                        <th className="p-4 text-center">W</th>
                        <th className="p-4 text-center">D</th>
                        <th className="p-4 text-center">L</th>
                        <th className="p-4 text-center">F</th>
                        <th className="p-4 text-center">A</th>
                        <th className="p-4 text-center">GD</th>
                        <th className="p-4 text-center rounded-r-lg">P</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {group.teams.map((team, j) => (
                        <tr key={j} className="hover:bg-white/5 transition-colors">
                          <td className="p-4 font-bold">{team.name}</td>
                          <td className="p-4 text-center">{team.gp}</td>
                          <td className="p-4 text-center">{team.w}</td>
                          <td className="p-4 text-center">{team.d}</td>
                          <td className="p-4 text-center">{team.l}</td>
                          <td className="p-4 text-center">{team.f}</td>
                          <td className="p-4 text-center">{team.a}</td>
                          <td className="p-4 text-center text-primary-red font-bold">{team.gd}</td>
                          <td className="p-4 text-center font-black text-lg">{team.p}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* --- Districts Grid --- */}
      <section className="py-20 bg-light-gray dark:bg-slate-950">
        <div className="container mx-auto px-4">
          <div className="bg-white dark:bg-slate-900 p-10 rounded-[2.5rem] shadow-xl border-t-8 border-primary-blue">
            <h2 className="text-3xl font-bold text-dark-blue dark:text-white mb-12 inline-block border-b-4 border-primary-blue pb-2">
              All Teams & Districts
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {DISTRICT_TEAMS.map((item, i) => (
                <div key={i} className="p-4 bg-light-gray dark:bg-slate-800 rounded-xl border border-medium-gray dark:border-slate-700 hover:border-primary-blue hover:translate-x-2 transition-all group">
                  <span className="font-black text-primary-red mr-2">{item.team}</span>
                  <span className="text-dark-gray dark:text-slate-400">- {item.district}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* --- Footer --- */}
      <footer className="bg-dark-blue text-white pt-20 pb-10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div className="space-y-6">
              <img 
                src="https://drive.google.com/thumbnail?id=1lC_4xPQEEoEpTJfeONZaDSVA-kjOB1n6" 
                alt="DNTV Uganda Logo" 
                className="h-16 w-auto object-contain invert brightness-0"
                referrerPolicy="no-referrer"
              />
              <p className="text-white/60 text-sm leading-relaxed">
                DNTV Uganda is a leading 24/7 news television station dedicated to delivering accurate, timely, and comprehensive news coverage across Uganda and beyond. We are committed to journalistic excellence and being your most reliable source of information.
              </p>
              <div className="flex gap-4">
                {[Facebook, Twitter, Youtube].map((Icon, i) => (
                  <a key={i} href="#" className="text-white/60 hover:text-primary-red transition-colors">
                    <Icon size={20} />
                  </a>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-bold mb-8">Quick Links</h3>
              <ul className="space-y-4 text-sm text-white/60">
                {["Home", "About DNTV", "News", "Politics", "Business", "Sports", "Contact Us"].map((link) => (
                  <li key={link}><a href="#" className="hover:text-primary-red transition-colors">{link}</a></li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-bold mb-8">News Categories</h3>
              <ul className="space-y-4 text-sm text-white/60">
                {["Breaking News", "Politics & Governance", "Business & Finance", "Sports", "Entertainment", "Lifestyle", "Weather"].map((link) => (
                  <li key={link}><a href="#" className="hover:text-primary-red transition-colors">{link}</a></li>
                ))}
              </ul>
            </div>

            <div className="space-y-8">
              <h3 className="text-lg font-bold">Our Platforms</h3>
              <div className="flex flex-wrap gap-3">
                {[
                  { icon: Globe, label: "Official Website" },
                  { icon: Tv, label: "Live TV" },
                  { icon: Podcast, label: "Podcasts" },
                  { icon: Newspaper, label: "E-Paper" },
                ].map((item, i) => (
                  <a key={i} href="#" className="flex items-center gap-2 px-4 py-2 bg-white/10 rounded-lg text-xs hover:bg-white/20 transition-all">
                    <item.icon size={14} />
                    {item.label}
                  </a>
                ))}
              </div>
              <div className="space-y-4 text-sm text-white/60">
                <div className="flex items-start gap-3">
                  <MapPin size={18} className="text-primary-red shrink-0" />
                  <span>Plot 24, Lumumba Avenue, Kampala, Uganda</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone size={18} className="text-primary-red shrink-0" />
                  <span>+256 200 999 594</span>
                </div>
                <div className="flex items-center gap-3">
                  <Mail size={18} className="text-primary-red shrink-0" />
                  <span>info@dntvuganda.com</span>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-white/10 text-center text-white/40 text-xs">
            <p>&copy; {new Date().getFullYear()} DNTV Uganda. All Rights Reserved. | Designed for Digital Excellence</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
